import { NextResponse } from "next/server";
import { WARDS } from "@/lib/wards";
import type { Ward } from "@/lib/types";
import { computeWardRisk } from "@/lib/risk";

export async function GET() {
  console.log("WARDS length", WARDS.length);

  try {
    const results: Ward[] = [];

    for (const wc of WARDS) {
      const url =
        `https://api.open-meteo.com/v1/forecast` +
        `?latitude=${wc.lat}&longitude=${wc.lon}` +
        `&daily=rain_sum,precipitation_probability_max` +
        `&timezone=auto`;

      const res = await fetch(url);

      let dailyRainMm = 0;
      let pop = 0;

      if (res.ok) {
        const weather = await res.json();
        dailyRainMm = weather.daily?.rain_sum?.[0] ?? 0;
        const popPercent =
          weather.daily?.precipitation_probability_max?.[0] ?? 0;
        pop = popPercent / 100; // 0–1
      } else {
        const text = await res.text();
        console.log("Open-Meteo error for", wc.id, res.status, text);
      }

      const reports24h = 0;

      const wardRisk = computeWardRisk(wc, {
        dailyRainMm,
        pop,
        reports24h,
      });

      results.push(wardRisk);
    }

    console.log("results length", results.length);
    return NextResponse.json(results);
  } catch (e) {
    console.error("risk/all error", e);
    return NextResponse.json({ error: "risk failed" }, { status: 500 });
  }
}
